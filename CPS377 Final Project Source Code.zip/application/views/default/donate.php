<section id="container-donate" class="page-container">
    <section id="section-donate" class="section-container">
        <h1>Let's keep this project going.</h1>
        <p>Visual-eyes relies solely on user donations to stay up and running.
            Any support will be greatly appreciated and will help ensure 
            you can create dope visualizations for eternity.</p>
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
            <input type="hidden" name="cmd" value="_donations" />
            <input type="hidden" name="business" value="nikanasta15@gmail.com" />
            <input type="hidden" name="currency_code" value="AUD" />
            <input type="image" src="https://www.paypalobjects.com/en_AU/i/btn/btn_donateCC_LG.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Donate with PayPal button" />
            <img alt="" border="0" src="https://www.paypal.com/en_AU/i/scr/pixel.gif" width="1" height="1" />
        </form>   
    </section>             
</section>
